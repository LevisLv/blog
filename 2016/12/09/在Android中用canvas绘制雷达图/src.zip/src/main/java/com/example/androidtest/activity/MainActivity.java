package com.example.androidtest.activity;

import java.util.ArrayList;
import java.util.List;

import com.example.androidtest.R;

import android.app.Activity;
import android.os.Bundle;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        RadarChart radarChart = (RadarChart) MainActivity.this.findViewById(R.id.radar_chart);

        List<Data> dataList = new ArrayList<>();
        for (int i = 1; i <= 6; i++) {
            Data data = new Data("name" + i, 0.1 * (i + 3));
            dataList.add(data);
        }

        radarChart.setDataList(dataList);
        radarChart.invalidate();
    }

}
