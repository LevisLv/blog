package com.example.androidtest.activity;

import java.util.List;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.view.View;

/**
 * @description:
 * @FileName: RadarChart.java
 * @author: lvlei
 * @date: 2016-12-09
 */

public class RadarChart extends View {

    // 字和小圆环的颜色
    private static final String[] COLOR_STRINGS = {"#00A0EA", "#F9B526", "#920683", "#E2027E", "#E3E809", "#19DBB6"};
    // 多边形填充色
    private static final String[] POLYGON_FILL_COLOR_STRINGS = {"#CCA8A8A8", "#99A8A8A8", "#66A8A8A8", "#33A8A8A8", "#4CFFFFFF"};
    // 多边形描边色
    private static final String POLYGON_STROKE_COLOR_STRING = "#E0E4E4";
    // 雷达图填充色
    private static final String RADAR_FILL_COLOR_STRING = "#4C16C4A6";
    // 雷达图描边色
    private static final String RADAR_STROKE_COLOR_STRING = "#16C4A8";

    private Paint mPaint;
    private float mCenterX;
    private float mCenterY;
    private float mMaxSideLength;
    private List<Data> mDataList;

    public void setDataList(List<Data> dataList) {
        mDataList = dataList;
    }

    public RadarChart(Context context) {
        super(context);
        initValue();
    }

    public RadarChart(Context context, AttributeSet attrs) {
        super(context, attrs);
        initValue();
    }

    public RadarChart(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initValue();
    }

    private void initValue() {
        DisplayMetrics dm = getResources().getDisplayMetrics();
        int screenWidth = dm.widthPixels;
        int screenHeight = dm.heightPixels;
        mCenterX = screenWidth / 2;
        mCenterY = screenHeight / 2;
        mMaxSideLength = screenWidth / 3;

        mPaint = new Paint();
        mPaint.setAntiAlias(true);
    }

    @Override
    public void onDraw(Canvas canvas) {
        drawRadarChart(canvas, mPaint, mMaxSideLength);
    }

    private void drawRadarChart(Canvas canvas, Paint paint, float maxSideLength) {
        Path path = new Path();
        int size = mDataList.size();
        float unitAngle = (float) (Math.PI * 2 / size);
        int polygonCount = POLYGON_FILL_COLOR_STRINGS.length;
        float radiusUnit = maxSideLength / polygonCount;

        // 绘制多边形，从最外层开始绘制，一层一层覆盖
        for (int i = polygonCount; i >= 1; i--) {
            float currentRadius = radiusUnit * i;

            // 每次绘制之前path要先reset
            path.reset();
            // path移动到正多边形的每个顶点
            for (int j = 0; j < size; j++) {
                float angle = unitAngle * j;
                float x = (float) (mCenterX + currentRadius * Math.sin(angle));
                float y = (float) (mCenterY - currentRadius * Math.cos(angle));
                if (j == 0) {
                    path.moveTo(x, y);
                } else {
                    path.lineTo(x, y);
                }
            }
            path.close();

            // 绘制多边形填充图
            paint.setColor(Color.parseColor(POLYGON_FILL_COLOR_STRINGS[i - 1]));
            paint.setStyle(Paint.Style.FILL);
            canvas.drawPath(path, paint);
            // 多边形描边
            paint.setColor(Color.parseColor(POLYGON_STROKE_COLOR_STRING));
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(1.0f);
            canvas.drawPath(path, paint);
        }

        // 绘制从中心出发的 size 条白线
        paint.setColor(Color.WHITE);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(1.0f);
        for (int i = 0; i < size; i++) {
            float angle = unitAngle * i;
            float stopX = (float) (mCenterX + maxSideLength * Math.sin(angle));
            float stopY = (float) (mCenterY - maxSideLength * Math.cos(angle));
            canvas.drawLine(mCenterX, mCenterY, stopX, stopY, paint);
        }

        // 绘制数据雷达图，依然要reset path
        path.reset();
        for (int i = 0; i < size; i++) {
            // 根据value计算雷达图的边长
            double value = mDataList.get(i).getValue();
            float angle = unitAngle * i;
            float x = (float) (mCenterX + value * maxSideLength * Math.sin(angle));
            float y = (float) (mCenterY - value * maxSideLength * Math.cos(angle));
            if (i == 0) {
                path.moveTo(x, y);
            } else {
                path.lineTo(x, y);
            }
        }
        path.close();

        // 绘制雷达图填充图
        paint.setColor(Color.parseColor(RADAR_FILL_COLOR_STRING));
        paint.setStyle(Paint.Style.FILL);
        canvas.drawPath(path, paint);
        // 雷达图描边
        paint.setColor(Color.parseColor(RADAR_STROKE_COLOR_STRING));
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(3.0f);

        // 绘制雷达图各顶点小圆环
        float outerRadius = 4.0f;
        float innerRadius = 3.0f;
        for (int i = 0; i < size; i++) {
            double value = mDataList.get(i).getValue();
            float angle = unitAngle * i;
            float cirX = (float) (mCenterX + value * maxSideLength * Math.sin(angle));
            float cirY = (float) (mCenterY - value * maxSideLength * Math.cos(angle));
            paint.setColor(Color.parseColor(COLOR_STRINGS[i % COLOR_STRINGS.length]));
            canvas.drawCircle(cirX, cirY, outerRadius, paint);

            paint.setColor(Color.WHITE);
            canvas.drawCircle(cirX, cirY, innerRadius, paint);
        }

        // 绘制文本
        drawText(canvas, paint, mDataList, mCenterX, mCenterY, maxSideLength, unitAngle);
    }

    private void drawText(Canvas canvas, Paint textPaint, List<Data> dataList, float centerX, float centerY, float radius, float unitAngle) {
        // 先设置字体大小
        textPaint.setTextSize(36.0f);
        textPaint.setStrokeWidth(0.0f);
        Paint.FontMetrics fontMetrics = textPaint.getFontMetrics();
        float textHeight = fontMetrics.descent - fontMetrics.ascent;

        int size = dataList.size();
        for (int i = 0; i < size; i++) {
            textPaint.setColor(Color.parseColor(COLOR_STRINGS[i % COLOR_STRINGS.length]));
            String title = dataList.get(i).getName();
            if (TextUtils.isEmpty(title)) {
                title = "";
            }

            float textWidth = textPaint.measureText(title);
            float angle = unitAngle * i;
            if (angle >= Math.PI * 2) {
                angle -= Math.PI * 2;
            }
            float x = (float) (centerX + (radius + textHeight / 2) * Math.sin(angle));
            float y = (float) (centerY - (radius + textHeight / 2) * Math.cos(angle));

            // 0 <= angle < 2 * Math.PI
            if (angle <= 0.01f || angle >= Math.PI * 2 - 0.01f) {
                // 0
                x -= textWidth / 2;
            } else if (angle < Math.PI / 2 - 0.01f) {
                // 第1象限
                // do nothing
            } else if (angle <= Math.PI / 2 + 0.01f) {
                // Math.PI / 2
                y += textHeight / 2;
            } else if (angle < Math.PI - 0.01f) {
                // 第4象限
                y += textHeight;
            } else if (angle <= Math.PI + 0.01f) {
                // Math.PI
                x -= textWidth / 2;
                y += textHeight;
            } else if (angle < Math.PI * 3 / 2 - 0.01f) {
                // 第3象限
                x -= textWidth;
                y += textHeight;
            } else if (angle <= Math.PI * 3 / 2 + 0.01f) {
                // Math.PI * 3 / 2
                x -= textWidth;
                y += textHeight;
            }  else if (angle < Math.PI * 2) {
                // 第2象限
                x -= textWidth;
            }

            canvas.drawText(title, x, y, textPaint);
        }
    }

}
