package com.example.androidtest.activity;

/**
 * @description:
 * @FileName: Data.java
 * @author: lvlei
 * @date: 2016-12-09
 */

public class Data {
    private String name;
    private double value; // >0 && <=1

    public Data(String name, double value) {
        this.name = name;
        this.value = value;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getValue() {
        return value;
    }

    public void setValue(double value) {
        this.value = value;
    }
}
