//
//  Data.m
//  getu
//
//  Created by lvlei on 2016/12/29.
//  Copyright © 2016年 getui. All rights reserved.
//

#import "Data.h"

@implementation Data

@end
