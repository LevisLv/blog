//
//  ViewController.h
//  getu
//
//  Created by lvlei on 2016/12/13.
//  Copyright © 2016年 getui. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Data.h"
#import "RadarView.h"

@interface ViewController : UIViewController


@end

