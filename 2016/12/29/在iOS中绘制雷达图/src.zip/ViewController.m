//
//  ViewController.m
//
//  Created by lvlei on 2016/12/26.
//  Copyright © 2016年 getui. All rights reserved.
//

#import "ViewController.h"
#import "Data.h"

@interface ViewController ()

@property (strong, nonatomic) IBOutlet RadarView *radarView;

@end

@implementation ViewController

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    
    NSMutableArray<Data *> *dataArray = [NSMutableArray new];
    Data *data = [Data new];
    [data setName:[NSString stringWithFormat:@"name%ld", 0L]];
    [data setValue:.5f];
    [dataArray addObject:data];
    
    for (NSInteger i = 2; i <= 3; i++) {
        Data *data = [Data new];
        [data setName:[NSString stringWithFormat:@"name%ld", i]];
        [data setValue:.2f * i];
        [dataArray addObject:data];
    }
    
    for (NSInteger i = 4; i <= 6; i++) {
        Data *data = [Data new];
        [data setName:[NSString stringWithFormat:@"name%ld", i]];
        [data setValue:.1f * i];
        [dataArray addObject:data];
    }
    
    [_radarView setDataArray:dataArray];
    [_radarView setNeedsDisplay];
}

@end
