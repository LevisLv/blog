//
//  Data.h
//  getu
//
//  Created by lvlei on 2016/12/29.
//  Copyright © 2016年 getui. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Data : NSObject

@property (strong, nonatomic) NSString *name;
@property (assign, nonatomic) double value;

@end
