package com.example.fcmtest;

import android.support.multidex.MultiDexApplication;

public class MyApplication extends MultiDexApplication {


}
